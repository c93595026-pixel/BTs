import { GoogleGenAI } from "@google/genai";
import { Lead } from "../types";

// Initialize Gemini AI
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateCallScript = async (lead: Lead, employeeName: string): Promise<string> => {
  try {
    const model = "gemini-2.5-flash";
    const prompt = `
      You are an expert real estate sales script writer.
      Create a short, professional, and persuasive phone call script for an employee named "${employeeName}".
      They are calling a potential customer named "${lead.name}".
      
      Context:
      - Location of interest: ${lead.location}
      - Current Status: ${lead.status}
      - Previous Feedback: ${lead.feedback || "None"}
      
      The goal is to move the customer to the next stage (e.g., schedule a visit or get more details).
      Keep it natural and under 100 words.
    `;

    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
    });

    return response.text.trim();
  } catch (error) {
    console.error("Error generating script:", error);
    return "Error generating script. Please try again or check your API key.";
  }
};

export const analyzeFeedback = async (feedback: string): Promise<string> => {
  try {
    const model = "gemini-2.5-flash";
    const prompt = `
      Analyze the following real estate customer feedback and categorize the sentiment (Positive, Neutral, Negative) and suggest the next best action in one sentence.
      
      Feedback: "${feedback}"
    `;

    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
    });

    return response.text.trim();
  } catch (error) {
    console.error("Error analyzing feedback:", error);
    return "Could not analyze feedback.";
  }
};
