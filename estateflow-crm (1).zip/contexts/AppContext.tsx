import React, { createContext, useContext, useReducer, useEffect, ReactNode } from 'react';
import { AppAction, AppState, AppContextType, User, Lead, UserRole } from '../types';

// Initial Dummy Data
const INITIAL_ADMIN: User = {
  id: 'admin',
  name: 'System Admin',
  role: UserRole.ADMIN,
  password: '12345', // Updated to match requirement
  availabilityStatus: 'WORKING'
};

const INITIAL_STATE: AppState = {
  currentUser: null,
  users: [INITIAL_ADMIN],
  leads: [],
};

const AppContext = createContext<AppContextType | undefined>(undefined);

const appReducer = (state: AppState, action: AppAction): AppState => {
  switch (action.type) {
    case 'SET_USER':
      return { ...state, currentUser: action.payload };
    case 'ADD_USER':
      return { ...state, users: [...state.users, action.payload] };
    case 'UPDATE_USER_PASSWORD':
      const updatedUsers = state.users.map((u) =>
        u.id === action.payload.userId ? { ...u, password: action.payload.newPass } : u
      );
      return {
        ...state,
        users: updatedUsers,
        // Update currentUser if the password change is for the logged-in user
        currentUser: state.currentUser?.id === action.payload.userId 
          ? { ...state.currentUser, password: action.payload.newPass } 
          : state.currentUser
      };
    case 'UPDATE_USER_STATUS':
      const usersWithNewStatus = state.users.map((u) =>
        u.id === action.payload.userId ? { ...u, availabilityStatus: action.payload.status } : u
      );
      return {
        ...state,
        users: usersWithNewStatus,
        currentUser: state.currentUser?.id === action.payload.userId
          ? { ...state.currentUser, availabilityStatus: action.payload.status }
          : state.currentUser
      };
    case 'DELETE_USERS':
      return {
        ...state,
        users: state.users.filter((u) => !action.payload.includes(u.id)),
        // Unassign leads from deleted users to prevent orphaned references
        leads: state.leads.map((l) =>
          l.assignedToId && action.payload.includes(l.assignedToId)
            ? { ...l, assignedToId: null, lastUpdated: new Date().toISOString() }
            : l
        ),
      };
    case 'ADD_LEADS':
      return { ...state, leads: [...state.leads, ...action.payload] };
    case 'UPDATE_LEAD':
      return {
        ...state,
        leads: state.leads.map((l) => (l.id === action.payload.id ? action.payload : l)),
      };
    case 'DELETE_LEADS':
      return {
        ...state,
        leads: state.leads.filter((l) => !action.payload.includes(l.id)),
      };
    case 'ASSIGN_LEADS':
      return {
        ...state,
        leads: state.leads.map((l) =>
          action.payload.leadIds.includes(l.id)
            ? { ...l, assignedToId: action.payload.employeeId, lastUpdated: new Date().toISOString() }
            : l
        ),
      };
    default:
      return state;
  }
};

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Load from local storage if available, else use initial
  const loadState = (): AppState => {
    // Changed key to v1 to force refresh state for password fix
    const saved = localStorage.getItem('estateflow_crm_v1');
    if (saved) {
      return JSON.parse(saved);
    }
    return INITIAL_STATE;
  };

  const [state, dispatch] = useReducer(appReducer, loadState());

  // Persist state changes
  useEffect(() => {
    localStorage.setItem('estateflow_crm_v1', JSON.stringify(state));
  }, [state]);

  const login = (id: string, pass: string): boolean => {
    // Case insensitive ID check
    const user = state.users.find((u) => u.id.toLowerCase() === id.toLowerCase() && u.password === pass);
    if (user) {
      dispatch({ type: 'SET_USER', payload: user });
      return true;
    }
    return false;
  };

  const logout = () => {
    dispatch({ type: 'SET_USER', payload: null });
  };

  return (
    <AppContext.Provider value={{ state, dispatch, login, logout }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
