import { Dispatch } from 'react';

export enum UserRole {
  ADMIN = 'ADMIN',
  EMPLOYEE = 'EMPLOYEE',
}

export type UserAvailability = 'WORKING' | 'ON_LEAVE';

export enum LeadStatus {
  NEW = 'New',
  INTERESTED = 'Interested',
  CALLBACK = 'Call Back',
  NOT_INTERESTED = 'Not Interested',
  CLOSED = 'Closed',
}

export interface User {
  id: string;
  name: string;
  role: UserRole;
  password?: string; // In a real app, this would be hashed
  phone?: string;
  address?: string;
  designation?: string;
  joiningDate?: string;
  experience?: string;
  availabilityStatus?: UserAvailability;
}

export interface Lead {
  id: string;
  name: string;
  phone: string;
  location: string;
  assignedToId?: string | null;
  status: LeadStatus;
  feedback: string;
  followUpDate?: string; // ISO or Local Date String
  createdAt: string;
  lastUpdated: string;
}

export interface AppState {
  currentUser: User | null;
  users: User[];
  leads: Lead[];
}

export type AppContextType = {
  state: AppState;
  dispatch: Dispatch<AppAction>;
  login: (id: string, pass: string) => boolean;
  logout: () => void;
};

export type AppAction =
  | { type: 'SET_USER'; payload: User | null }
  | { type: 'ADD_USER'; payload: User }
  | { type: 'UPDATE_USER_PASSWORD'; payload: { userId: string; newPass: string } }
  | { type: 'UPDATE_USER_STATUS'; payload: { userId: string; status: UserAvailability } }
  | { type: 'DELETE_USERS'; payload: string[] }
  | { type: 'ADD_LEADS'; payload: Lead[] }
  | { type: 'UPDATE_LEAD'; payload: Lead }
  | { type: 'DELETE_LEADS'; payload: string[] } // ids
  | { type: 'ASSIGN_LEADS'; payload: { leadIds: string[]; employeeId: string | null } };
