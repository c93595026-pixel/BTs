import React from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AppProvider } from './contexts/AppContext';
import { Login } from './pages/Login';
import { AdminDashboard } from './pages/admin/AdminDashboard';
import { Employees } from './pages/admin/Employees';
import { DataUpload } from './pages/admin/DataUpload';
import { DataDistribution } from './pages/admin/DataDistribution';
import { FeedbackLogs } from './pages/admin/FeedbackLogs';
import { AllData } from './pages/admin/AllData';
import { EmployeeDashboard } from './pages/employee/EmployeeDashboard';
import { WorkPage } from './pages/employee/WorkPage';

function App() {
  return (
    <AppProvider>
      <HashRouter>
        <Routes>
          <Route path="/" element={<Login />} />
          
          {/* Admin Routes */}
          <Route path="/admin/dashboard" element={<AdminDashboard />} />
          <Route path="/admin/alldata" element={<AllData />} />
          <Route path="/admin/upload" element={<DataUpload />} />
          <Route path="/admin/distribution" element={<DataDistribution />} />
          <Route path="/admin/employees" element={<Employees />} />
          <Route path="/admin/feedback" element={<FeedbackLogs />} />

          {/* Employee Routes */}
          <Route path="/employee/dashboard" element={<EmployeeDashboard />} />
          <Route path="/employee/work" element={<WorkPage />} />
          
          {/* Fallback */}
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </HashRouter>
    </AppProvider>
  );
}

export default App;