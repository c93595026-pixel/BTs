import React from 'react';
import { Layout } from '../../components/Layout';
import { useApp } from '../../contexts/AppContext';
import { LeadStatus, UserAvailability } from '../../types';
import { Icons } from '../../components/Icons';
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, Legend } from 'recharts';

export const EmployeeDashboard: React.FC = () => {
  const { state, dispatch } = useApp();
  const myLeads = state.leads.filter(l => l.assignedToId === state.currentUser?.id);
  const currentStatus = state.currentUser?.availabilityStatus || 'WORKING';

  const updateStatus = (status: UserAvailability) => {
    if (state.currentUser) {
      dispatch({
        type: 'UPDATE_USER_STATUS',
        payload: { userId: state.currentUser.id, status }
      });
    }
  };

  const stats = {
    total: myLeads.length,
    interested: myLeads.filter(l => l.status === LeadStatus.INTERESTED).length,
    callback: myLeads.filter(l => l.status === LeadStatus.CALLBACK).length,
    notInterested: myLeads.filter(l => l.status === LeadStatus.NOT_INTERESTED).length,
    new: myLeads.filter(l => l.status === LeadStatus.NEW).length,
  };

  const upcomingFollowUps = myLeads
    .filter(l => l.followUpDate)
    .sort((a, b) => new Date(a.followUpDate!).getTime() - new Date(b.followUpDate!).getTime());

  const chartData = [
    { name: 'Interested', value: stats.interested, color: '#10b981' },
    { name: 'Callback', value: stats.callback, color: '#f59e0b' },
    { name: 'Not Interested', value: stats.notInterested, color: '#ef4444' },
    { name: 'New', value: stats.new, color: '#6366f1' },
  ];

  const StatCard = ({ title, value, icon: Icon, color }: any) => (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
      <div className="flex justify-between items-center">
        <div>
          <p className="text-sm font-medium text-gray-500">{title}</p>
          <h3 className="text-3xl font-bold text-gray-900 mt-1">{value}</h3>
        </div>
        <div className={`p-3 rounded-lg ${color.bg}`}>
          <Icon className={`w-6 h-6 ${color.text}`} />
        </div>
      </div>
    </div>
  );

  return (
    <Layout>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">My Dashboard</h1>
          <p className="text-gray-500">Welcome back, {state.currentUser?.name}.</p>
        </div>

        {/* Status Toggle Buttons */}
        <div className="flex bg-white rounded-lg p-1.5 shadow-sm border border-gray-200">
            <button 
                onClick={() => updateStatus('WORKING')}
                className={`flex items-center gap-2 px-6 py-2 rounded-md text-sm font-bold transition-all ${
                    currentStatus === 'WORKING' 
                    ? 'bg-green-600 text-white shadow-sm' 
                    : 'text-gray-500 hover:bg-gray-50'
                }`}
            >
                <Icons.Briefcase className="w-4 h-4" />
                Work
            </button>
            <button 
                onClick={() => updateStatus('ON_LEAVE')}
                className={`flex items-center gap-2 px-6 py-2 rounded-md text-sm font-bold transition-all ${
                    currentStatus === 'ON_LEAVE' 
                    ? 'bg-orange-500 text-white shadow-sm' 
                    : 'text-gray-500 hover:bg-gray-50'
                }`}
            >
                <Icons.Coffee className="w-4 h-4" />
                Leave
            </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard title="Total Calls" value={stats.total} icon={Icons.Phone} color={{ bg: 'bg-blue-50', text: 'text-blue-600' }} />
        <StatCard title="Interested" value={stats.interested} icon={Icons.Sparkles} color={{ bg: 'bg-green-50', text: 'text-green-600' }} />
        <StatCard title="Call Back" value={stats.callback} icon={Icons.Briefcase} color={{ bg: 'bg-yellow-50', text: 'text-yellow-600' }} />
        <StatCard title="Not Interested" value={stats.notInterested} icon={Icons.LogOut} color={{ bg: 'bg-red-50', text: 'text-red-600' }} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Charts */}
        <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-100">
           <h2 className="text-lg font-bold text-gray-900 mb-4">Lead Status Distribution</h2>
           <div className="h-64">
             <ResponsiveContainer width="100%" height="100%">
               <PieChart>
                 <Pie
                   data={chartData}
                   cx="50%"
                   cy="50%"
                   innerRadius={60}
                   outerRadius={80}
                   paddingAngle={5}
                   dataKey="value"
                 >
                   {chartData.map((entry, index) => (
                     <Cell key={`cell-${index}`} fill={entry.color} />
                   ))}
                 </Pie>
                 <Tooltip />
                 <Legend verticalAlign="middle" align="right" layout="vertical" iconType="circle" />
               </PieChart>
             </ResponsiveContainer>
           </div>
        </div>

        {/* Right Column: Quick Actions & Follow ups */}
        <div className="space-y-6">
           {/* Quick Action */}
            <button onClick={() => window.location.href='#/employee/work'} className="w-full py-4 px-6 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl transition-colors text-left flex items-center justify-between group shadow-lg shadow-indigo-200">
                <div>
                    <span className="block font-bold text-lg">Start Calling Session</span>
                    <span className="text-indigo-100 text-sm font-normal">Continue where you left off</span>
                </div>
                <Icons.Phone className="w-6 h-6 group-hover:translate-x-1 transition-transform" />
            </button>

            {/* Upcoming Follow-ups */}
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 flex-1">
                <h2 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                    <Icons.Clock className="w-5 h-5 text-orange-500" />
                    Upcoming Follow-ups
                </h2>
                <div className="space-y-3 max-h-80 overflow-y-auto pr-2">
                    {upcomingFollowUps.length === 0 ? (
                        <p className="text-gray-400 text-sm text-center py-4">No upcoming follow-ups scheduled.</p>
                    ) : (
                        upcomingFollowUps.map(lead => (
                            <div key={lead.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg border border-gray-100 hover:bg-orange-50 transition-colors cursor-pointer" onClick={() => window.location.href='#/employee/work'}>
                                <div>
                                    <h4 className="font-medium text-gray-900 text-sm">{lead.name}</h4>
                                    <p className="text-xs text-gray-500">{new Date(lead.followUpDate!).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short'})}</p>
                                </div>
                                <div className="text-xs font-medium text-orange-600 bg-orange-100 px-2 py-1 rounded-full">
                                    {lead.status}
                                </div>
                            </div>
                        ))
                    )}
                </div>
            </div>
        </div>
      </div>
    </Layout>
  );
};
