import React, { useState } from 'react';
import { Layout } from '../../components/Layout';
import { useApp } from '../../contexts/AppContext';
import { Lead, LeadStatus } from '../../types';
import { Icons } from '../../components/Icons';
import { generateCallScript, analyzeFeedback } from '../../services/geminiService';

export const WorkPage: React.FC = () => {
  const { state, dispatch } = useApp();
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);
  const [feedback, setFeedback] = useState('');
  const [status, setStatus] = useState<LeadStatus>(LeadStatus.NEW);
  const [followUpDate, setFollowUpDate] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [aiScript, setAiScript] = useState<string>('');
  const [isGeneratingScript, setIsGeneratingScript] = useState(false);
  const [aiFeedbackAnalysis, setAiFeedbackAnalysis] = useState<string>('');
  const [isAnalyzingFeedback, setIsAnalyzingFeedback] = useState(false);

  const myLeads = state.leads.filter(
    l => l.assignedToId === state.currentUser?.id &&
    (l.name.toLowerCase().includes(searchTerm.toLowerCase()) || l.phone.includes(searchTerm))
  );

  const handleLeadClick = (lead: Lead) => {
    setSelectedLead(lead);
    setFeedback(lead.feedback || '');
    setStatus(lead.status);
    setFollowUpDate(lead.followUpDate || '');
    setAiScript('');
    setAiFeedbackAnalysis('');
    setIsAnalyzingFeedback(false);
  };

  const handleSave = () => {
    if (selectedLead) {
      dispatch({
        type: 'UPDATE_LEAD',
        payload: {
          ...selectedLead,
          feedback,
          status,
          followUpDate,
          lastUpdated: new Date().toISOString()
        }
      });
      
      if (feedback.trim()) {
        setIsAnalyzingFeedback(true);
        analyzeFeedback(feedback).then(result => {
             setAiFeedbackAnalysis(result);
             setIsAnalyzingFeedback(false);
        });
      } else {
        setAiFeedbackAnalysis('');
      }

      alert('Update saved!');
    }
  };

  const handleGenerateScript = async () => {
    if (!selectedLead || !state.currentUser) return;
    setIsGeneratingScript(true);
    const script = await generateCallScript(selectedLead, state.currentUser.name);
    setAiScript(script);
    setIsGeneratingScript(false);
  };

  return (
    <Layout>
      <div className="flex flex-col h-[calc(100vh-6rem)] md:h-[calc(100vh-4rem)] -m-4 md:-m-0">
        <div className="flex h-full bg-white md:rounded-xl shadow-sm overflow-hidden border-t md:border border-gray-200">
          
          {/* Left: Lead List - Hidden on mobile if lead is selected */}
          <div className={`${selectedLead ? 'hidden md:flex' : 'flex'} w-full md:w-1/3 border-r border-gray-200 flex-col bg-gray-50`}>
            <div className="p-4 border-b border-gray-200 bg-white z-10">
              <h2 className="font-bold text-gray-800 mb-3 text-lg">My Leads</h2>
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search name or phone..."
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none text-sm"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                <Icons.Search className="w-4 h-4 absolute left-3 top-3 text-gray-400" />
              </div>
            </div>
            
            <div className="flex-1 overflow-y-auto">
              {myLeads.length === 0 ? (
                 <div className="p-8 text-center text-gray-400 text-sm">No leads found.</div>
              ) : (
                myLeads.map(lead => (
                  <div
                    key={lead.id}
                    onClick={() => handleLeadClick(lead)}
                    className={`p-4 border-b border-gray-100 cursor-pointer transition-colors hover:bg-white ${selectedLead?.id === lead.id ? 'bg-white border-l-4 border-l-indigo-600 shadow-sm' : ''}`}
                  >
                    <div className="flex justify-between items-start mb-1">
                      <h4 className={`font-medium ${selectedLead?.id === lead.id ? 'text-indigo-700' : 'text-gray-900'}`}>{lead.name}</h4>
                      <span className={`text-[10px] px-2 py-0.5 rounded-full ${
                        lead.status === LeadStatus.INTERESTED ? 'bg-green-100 text-green-700' :
                        lead.status === LeadStatus.NOT_INTERESTED ? 'bg-red-100 text-red-700' :
                        'bg-gray-100 text-gray-600'
                      }`}>{lead.status}</span>
                    </div>
                    <p className="text-xs text-gray-500 mb-1">{lead.location}</p>
                    <div className="flex justify-between items-center">
                       <p className="text-xs text-gray-400 font-mono">{lead.phone}</p>
                       {lead.followUpDate && <Icons.Clock className="w-3 h-3 text-orange-400" />}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Right: Detail View - Hidden on mobile if no lead is selected */}
          <div className={`${selectedLead ? 'flex' : 'hidden md:flex'} w-full md:flex-1 flex-col bg-white h-full`}>
            {selectedLead ? (
              <>
                {/* Header */}
                <div className="p-4 md:p-6 border-b border-gray-100 flex justify-between items-center bg-white sticky top-0 z-20">
                  <div className="flex items-center gap-3">
                    <button onClick={() => setSelectedLead(null)} className="md:hidden p-1 rounded-full hover:bg-gray-100">
                        <Icons.ArrowLeft className="w-6 h-6 text-gray-600" />
                    </button>
                    <div>
                        <h1 className="text-xl md:text-2xl font-bold text-gray-900">{selectedLead.name}</h1>
                        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-1">
                          <span className="flex items-center gap-1 text-xs text-gray-500">
                            <Icons.Phone className="w-3 h-3" /> {selectedLead.phone}
                          </span>
                          <span className="flex items-center gap-1 text-xs text-gray-500">
                             <Icons.Home className="w-3 h-3" /> {selectedLead.location}
                          </span>
                        </div>
                    </div>
                  </div>
                  <div className="flex gap-2 md:gap-3">
                    <a
                      href={`tel:${selectedLead.phone}`}
                      className="bg-indigo-600 hover:bg-indigo-700 text-white p-2 md:p-3 rounded-full shadow-lg shadow-indigo-200 transition-transform hover:scale-105 flex items-center justify-center"
                      title="Call Customer"
                    >
                      <Icons.Phone className="w-5 h-5" />
                    </a>
                    <a
                      href={`https://wa.me/${selectedLead.phone.replace(/\D/g, '')}`}
                      target="_blank"
                      rel="noreferrer"
                      className="bg-green-500 hover:bg-green-600 text-white p-2 md:p-3 rounded-full shadow-lg shadow-green-200 transition-transform hover:scale-105 flex items-center justify-center"
                      title="WhatsApp"
                    >
                      <Icons.MessageCircle className="w-5 h-5" />
                    </a>
                  </div>
                </div>

                <div className="flex-1 p-4 md:p-6 overflow-y-auto">
                   
                   {/* Lead Info Card */}
                   <div className="bg-gray-50 rounded-xl p-4 border border-gray-100 mb-6">
                      <h3 className="text-sm font-bold text-gray-900 mb-3">Lead Information</h3>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                         <div>
                            <p className="text-xs text-gray-500">Added On</p>
                            <p className="text-sm font-medium text-gray-900">{new Date(selectedLead.createdAt).toLocaleDateString()}</p>
                         </div>
                         <div>
                            <p className="text-xs text-gray-500">Last Updated</p>
                            <p className="text-sm font-medium text-gray-900">{new Date(selectedLead.lastUpdated).toLocaleDateString()}</p>
                         </div>
                         <div>
                            <p className="text-xs text-gray-500">Location</p>
                            <p className="text-sm font-medium text-gray-900">{selectedLead.location}</p>
                         </div>
                         <div>
                            <p className="text-xs text-gray-500">Current Status</p>
                            <span className={`inline-block mt-1 px-2 py-0.5 rounded text-xs font-medium ${
                              selectedLead.status === LeadStatus.INTERESTED ? 'bg-green-100 text-green-700' :
                              selectedLead.status === LeadStatus.NOT_INTERESTED ? 'bg-red-100 text-red-700' :
                              'bg-gray-200 text-gray-700'
                            }`}>
                              {selectedLead.status}
                            </span>
                         </div>
                      </div>
                   </div>

                  {/* AI Section */}
                  <div className="mb-6 p-4 bg-indigo-50 rounded-xl border border-indigo-100">
                    <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-3 gap-2">
                      <h3 className="font-bold text-indigo-900 flex items-center gap-2 text-sm">
                        <Icons.Sparkles className="w-4 h-4" />
                        AI Sales Assistant
                      </h3>
                      <button 
                        onClick={handleGenerateScript}
                        disabled={isGeneratingScript}
                        className="w-full md:w-auto text-xs bg-white text-indigo-600 border border-indigo-200 px-3 py-1.5 rounded-lg hover:bg-indigo-50 transition-colors text-center"
                      >
                        {isGeneratingScript ? 'Thinking...' : 'Generate Pitch Script'}
                      </button>
                    </div>
                    {aiScript ? (
                      <div className="text-sm text-indigo-800 italic bg-white p-3 rounded-lg border border-indigo-100 shadow-sm">
                        "{aiScript}"
                      </div>
                    ) : (
                      <p className="text-xs text-indigo-400">Click generate to get a customized opening script for this lead.</p>
                    )}
                  </div>

                  {/* Forms */}
                  <div className="space-y-6 pb-20 md:pb-0">
                    <div className="bg-white rounded-xl border border-gray-100 p-4 shadow-sm">
                      <label className="block text-sm font-bold text-gray-900 mb-3">Update Status</label>
                      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2">
                        {Object.values(LeadStatus).map((s) => (
                          <button
                            key={s}
                            onClick={() => setStatus(s)}
                            className={`py-2 px-2 rounded-lg text-xs font-medium border transition-all ${
                              status === s
                                ? 'bg-gray-900 text-white border-gray-900'
                                : 'bg-white text-gray-600 border-gray-200 hover:bg-gray-50'
                            }`}
                          >
                            {s}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="bg-white rounded-xl border border-gray-100 p-4 shadow-sm">
                      <label className="block text-sm font-bold text-gray-900 mb-3 flex items-center gap-2">
                        <Icons.Calendar className="w-4 h-4 text-gray-500" />
                        Schedule Follow-up
                      </label>
                      <input 
                        type="datetime-local" 
                        value={followUpDate}
                        onChange={(e) => setFollowUpDate(e.target.value)}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none text-sm"
                      />
                      <p className="text-xs text-gray-400 mt-2">Set a date and time to call this customer back.</p>
                    </div>

                    <div className="bg-white rounded-xl border border-gray-100 p-4 shadow-sm">
                      <label className="block text-sm font-bold text-gray-900 mb-3">Call Notes / Feedback</label>
                      <textarea
                        value={feedback}
                        onChange={(e) => setFeedback(e.target.value)}
                        className="w-full h-32 p-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none resize-none text-sm"
                        placeholder="Enter detailed notes about the call, customer interest level, etc..."
                      ></textarea>
                      
                       {/* AI Analysis Result */}
                       {(isAnalyzingFeedback || aiFeedbackAnalysis) && (
                          <div className={`mt-3 p-3 rounded-lg text-xs ${isAnalyzingFeedback ? 'bg-gray-50 text-gray-500' : 'bg-indigo-50 text-indigo-800 border border-indigo-100'}`}>
                              <div className="flex items-center gap-2 font-bold mb-1">
                                  <Icons.Sparkles className="w-3 h-3" />
                                  {isAnalyzingFeedback ? 'Analyzing feedback...' : 'AI Insight'}
                              </div>
                              {!isAnalyzingFeedback && <p>{aiFeedbackAnalysis}</p>}
                          </div>
                       )}
                    </div>
                  </div>
                </div>

                {/* Footer Action */}
                <div className="p-4 md:p-6 border-t border-gray-100 bg-white sticky bottom-0 md:relative z-10">
                  <button
                    onClick={handleSave}
                    className="w-full bg-indigo-600 text-white py-3 rounded-xl font-bold hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-200"
                  >
                    Save All Changes
                  </button>
                </div>
              </>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center text-gray-400 p-8 bg-gray-50/50">
                <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center mb-4 shadow-sm border border-gray-100">
                  <Icons.Briefcase className="w-8 h-8 text-gray-300" />
                </div>
                <p className="text-lg font-medium text-gray-500">Select a lead to start working</p>
                <p className="text-sm mt-1">Choose from the list on the left to view details</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
};
