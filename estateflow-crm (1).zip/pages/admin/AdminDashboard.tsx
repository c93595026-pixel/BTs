import React, { useState } from 'react';
import { Layout } from '../../components/Layout';
import { useApp } from '../../contexts/AppContext';
import { Lead, LeadStatus, UserRole } from '../../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Icons } from '../../components/Icons';

export const AdminDashboard: React.FC = () => {
  const { state } = useApp();
  const [detailModal, setDetailModal] = useState<{ title: string; leads: Lead[] } | null>(null);

  const totalLeads = state.leads.length;
  const assignedLeads = state.leads.filter(l => l.assignedToId).length;
  const unassignedLeads = totalLeads - assignedLeads;
  const closedLeads = state.leads.filter(l => l.status === LeadStatus.CLOSED || l.status === LeadStatus.INTERESTED).length;

  // Prepare data for employee performance chart
  const employeePerformance = state.users
    .filter(u => u.role === UserRole.EMPLOYEE)
    .map(emp => {
      const empLeads = state.leads.filter(l => l.assignedToId === emp.id);
      return {
        id: emp.id,
        name: emp.name,
        Total: empLeads.length,
        Interested: empLeads.filter(l => l.status === LeadStatus.INTERESTED).length,
        Closed: empLeads.filter(l => l.status === LeadStatus.CLOSED).length,
      };
    });

  const handleBarClick = (data: any, category: 'Total' | 'Interested' | 'Closed') => {
    if (!data || !data.id) return;

    const empName = data.name;
    let filteredLeads: Lead[] = [];
    let title = '';

    if (category === 'Interested') {
      filteredLeads = state.leads.filter(l => l.assignedToId === data.id && l.status === LeadStatus.INTERESTED);
      title = `Interested Leads - ${empName}`;
    } else if (category === 'Closed') {
      filteredLeads = state.leads.filter(l => l.assignedToId === data.id && l.status === LeadStatus.CLOSED);
      title = `Closed Leads - ${empName}`;
    } else {
      // Total
      filteredLeads = state.leads.filter(l => l.assignedToId === data.id);
      title = `Total Assigned Leads - ${empName}`;
    }

    setDetailModal({ title, leads: filteredLeads });
  };

  const StatCard = ({ title, value, sub, icon: Icon, color }: any) => (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
      <div className="flex justify-between items-start">
        <div>
          <p className="text-sm font-medium text-gray-500">{title}</p>
          <h3 className="text-3xl font-bold text-gray-900 mt-2">{value}</h3>
          <p className={`text-xs mt-1 ${color}`}>{sub}</p>
        </div>
        <div className={`p-2 rounded-lg ${color.replace('text-', 'bg-').replace('600', '100')}`}>
          <Icon className={`w-6 h-6 ${color}`} />
        </div>
      </div>
    </div>
  );

  return (
    <Layout>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
        <p className="text-gray-500">Overview of system performance and lead distribution.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <StatCard title="Total Leads" value={totalLeads} sub="All time data" icon={Icons.Users} color="text-blue-600" />
        <StatCard title="Assigned Leads" value={assignedLeads} sub={`${Math.round((assignedLeads/totalLeads || 0)*100)}% distributed`} icon={Icons.Share} color="text-indigo-600" />
        <StatCard title="Unassigned" value={unassignedLeads} sub="Ready to distribute" icon={Icons.Briefcase} color="text-orange-600" />
        <StatCard title="Interested/Closed" value={closedLeads} sub="Positive conversions" icon={Icons.Sparkles} color="text-green-600" />
      </div>

      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 mb-8">
        <h2 className="text-lg font-bold text-gray-900 mb-4">Employee Performance <span className="text-xs font-normal text-gray-500 ml-2">(Click bars to view leads)</span></h2>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={employeePerformance}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip 
                contentStyle={{ backgroundColor: '#fff', borderRadius: '8px', border: '1px solid #e5e7eb' }} 
                cursor={{ fill: '#f9fafb' }}
              />
              <Legend />
              <Bar 
                dataKey="Total" 
                fill="#e0e7ff" 
                radius={[4, 4, 0, 0]} 
                onClick={(data) => handleBarClick(data, 'Total')}
                cursor="pointer"
              />
              <Bar 
                dataKey="Interested" 
                fill="#6366f1" 
                radius={[4, 4, 0, 0]} 
                onClick={(data) => handleBarClick(data, 'Interested')}
                cursor="pointer"
              />
              <Bar 
                dataKey="Closed" 
                fill="#10b981" 
                radius={[4, 4, 0, 0]} 
                onClick={(data) => handleBarClick(data, 'Closed')}
                cursor="pointer"
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Details Modal */}
      {detailModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl w-full max-w-6xl max-h-[80vh] flex flex-col shadow-2xl">
            <div className="p-6 border-b border-gray-100 flex justify-between items-center">
              <h3 className="text-xl font-bold text-gray-900">{detailModal.title}</h3>
              <button onClick={() => setDetailModal(null)} className="p-1 hover:bg-gray-100 rounded-full transition-colors">
                <Icons.X className="w-6 h-6 text-gray-500" />
              </button>
            </div>
            
            <div className="p-6 overflow-y-auto">
              {detailModal.leads.length === 0 ? (
                <div className="text-center py-12 text-gray-500">
                  <Icons.Briefcase className="w-12 h-12 mx-auto text-gray-300 mb-3" />
                  <p>No leads found for this category.</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm text-left">
                    <thead className="text-gray-500 bg-gray-50 sticky top-0">
                      <tr>
                        <th className="px-4 py-2 rounded-tl-lg">Name</th>
                        <th className="px-4 py-2">Phone</th>
                        <th className="px-4 py-2">Location</th>
                        <th className="px-4 py-2">Status</th>
                        <th className="px-4 py-2">Feedback</th>
                        <th className="px-4 py-2">Follow-up</th>
                        <th className="px-4 py-2 rounded-tr-lg">Last Updated</th>
                      </tr>
                    </thead>
                    <tbody>
                      {detailModal.leads.map((lead) => (
                        <tr key={lead.id} className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                          <td className="px-4 py-3 font-medium text-gray-900">{lead.name}</td>
                          <td className="px-4 py-3 font-mono text-gray-600">{lead.phone}</td>
                          <td className="px-4 py-3 text-gray-600">{lead.location}</td>
                          <td className="px-4 py-3">
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                              lead.status === LeadStatus.INTERESTED ? 'bg-green-100 text-green-700' :
                              lead.status === LeadStatus.CLOSED ? 'bg-emerald-100 text-emerald-700' :
                              lead.status === LeadStatus.CALLBACK ? 'bg-yellow-100 text-yellow-700' :
                              lead.status === LeadStatus.NOT_INTERESTED ? 'bg-red-100 text-red-700' :
                              'bg-gray-100 text-gray-600'
                            }`}>
                              {lead.status}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-gray-600 max-w-[200px] truncate" title={lead.feedback}>
                            {lead.feedback || <span className="text-gray-300 italic">No feedback</span>}
                          </td>
                          <td className="px-4 py-3 text-xs text-gray-600 whitespace-nowrap">
                             {lead.followUpDate ? (
                                <div className="flex flex-col">
                                  <span>{new Date(lead.followUpDate).toLocaleDateString()}</span>
                                  <span className="text-gray-400">{new Date(lead.followUpDate).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                                </div>
                              ) : '-'}
                          </td>
                          <td className="px-4 py-3 text-gray-400 text-xs">
                            {new Date(lead.lastUpdated).toLocaleDateString()}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            <div className="p-4 border-t border-gray-100 bg-gray-50 rounded-b-xl flex justify-end">
              <button 
                onClick={() => setDetailModal(null)}
                className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 font-medium shadow-sm"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </Layout>
  );
};