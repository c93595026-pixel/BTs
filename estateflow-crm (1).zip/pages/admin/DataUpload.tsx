import React, { useState, useRef } from 'react';
import { Layout } from '../../components/Layout';
import { useApp } from '../../contexts/AppContext';
import { Lead, LeadStatus } from '../../types';
import { Icons } from '../../components/Icons';

export const DataUpload: React.FC = () => {
  const { dispatch } = useApp();
  const [rawText, setRawText] = useState('');
  const [preview, setPreview] = useState<Lead[]>([]);
  const [error, setError] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const parseCSV = (text: string) => {
    const lines = text.trim().split('\n');
    const parsedLeads: Lead[] = [];
    
    // Simple parser assuming Header: Name, Phone, Location
    
    lines.forEach((line, index) => {
      const cols = line.split(',').map(c => c.trim());
      if (cols.length >= 3) {
        // Skip header if it looks like "Name, Phone"
        if (index === 0 && cols[0].toLowerCase().includes('name')) return;

        parsedLeads.push({
          id: `lead_${Date.now()}_${index}`,
          name: cols[0],
          phone: cols[1],
          location: cols[2],
          status: LeadStatus.NEW,
          feedback: '',
          createdAt: new Date().toISOString(),
          lastUpdated: new Date().toISOString(),
          assignedToId: null
        });
      }
    });
    return parsedLeads;
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      setRawText(text);
      const parsed = parseCSV(text);
      setPreview(parsed);
    };
    reader.readAsText(file);
  };

  const handleManualPaste = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setRawText(e.target.value);
    const parsed = parseCSV(e.target.value);
    setPreview(parsed);
  };

  const handleImport = () => {
    if (preview.length === 0) {
      setError('No valid data to import.');
      return;
    }
    dispatch({ type: 'ADD_LEADS', payload: preview });
    setRawText('');
    setPreview([]);
    alert(`Successfully imported ${preview.length} leads.`);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleDownloadFormat = () => {
    const csvContent = "Name, Phone Number, Location\nJohn Doe, 9876543210, New York\nJane Smith, 1234567890, Los Angeles";
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'lead_upload_format.csv');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <Layout>
      <div className="max-w-4xl mx-auto">
        <div className="mb-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Bulk Data Upload</h1>
            <p className="text-gray-500">Import customer leads via CSV or manual entry.</p>
          </div>
          <button 
            onClick={handleDownloadFormat}
            className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-200 text-gray-700 rounded-lg hover:bg-gray-50 text-sm font-medium shadow-sm"
          >
            <Icons.Download className="w-4 h-4" />
            Download Format
          </button>
        </div>

        <div className="bg-white p-6 md:p-8 rounded-xl shadow-sm border border-gray-100 mb-8">
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 md:p-10 text-center hover:bg-gray-50 transition-colors cursor-pointer" onClick={() => fileInputRef.current?.click()}>
            <Icons.Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900">Click to Upload CSV</h3>
            <p className="text-sm text-gray-500 mt-2">Format: Name, Phone Number, Location</p>
            <input 
              type="file" 
              ref={fileInputRef} 
              className="hidden" 
              accept=".csv,.txt" 
              onChange={handleFileUpload}
            />
          </div>

          <div className="mt-8">
            <label className="block text-sm font-medium text-gray-700 mb-2">Or paste data here (CSV format)</label>
            <textarea
              className="w-full h-32 p-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none font-mono text-sm"
              placeholder="John Doe, 555-0123, New York&#10;Jane Smith, 555-0987, Los Angeles"
              value={rawText}
              onChange={handleManualPaste}
            />
          </div>

          {preview.length > 0 && (
            <div className="mt-8">
              <h4 className="font-medium text-gray-900 mb-3">Preview ({preview.length} records)</h4>
              <div className="max-h-60 overflow-y-auto border border-gray-200 rounded-lg">
                <table className="w-full text-sm text-left">
                  <thead className="bg-gray-50 text-gray-500 font-medium sticky top-0">
                    <tr>
                      <th className="px-4 py-2">Name</th>
                      <th className="px-4 py-2">Phone</th>
                      <th className="px-4 py-2">Location</th>
                    </tr>
                  </thead>
                  <tbody>
                    {preview.map((lead) => (
                      <tr key={lead.id} className="border-t border-gray-100">
                        <td className="px-4 py-2">{lead.name}</td>
                        <td className="px-4 py-2">{lead.phone}</td>
                        <td className="px-4 py-2">{lead.location}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              
              <div className="mt-6 flex justify-end">
                <button
                  onClick={handleImport}
                  className="bg-indigo-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-indigo-700 transition-colors"
                >
                  Import Data
                </button>
              </div>
            </div>
          )}
          
          {error && <p className="mt-4 text-red-600 text-sm">{error}</p>}
        </div>
      </div>
    </Layout>
  );
};