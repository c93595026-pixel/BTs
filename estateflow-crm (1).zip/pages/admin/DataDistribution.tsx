import React, { useState } from 'react';
import { Layout } from '../../components/Layout';
import { useApp } from '../../contexts/AppContext';
import { UserRole } from '../../types';

export const DataDistribution: React.FC = () => {
  const { state, dispatch } = useApp();
  const [selectedEmployee, setSelectedEmployee] = useState<string>('');
  const [selectedLeads, setSelectedLeads] = useState<Set<string>>(new Set());
  
  const employees = state.users.filter(u => u.role === UserRole.EMPLOYEE);
  const unassignedLeads = state.leads.filter(l => !l.assignedToId);

  const handleToggleLead = (id: string) => {
    const newSet = new Set(selectedLeads);
    if (newSet.has(id)) newSet.delete(id);
    else newSet.add(id);
    setSelectedLeads(newSet);
  };

  const handleSelectAll = () => {
    if (selectedLeads.size === unassignedLeads.length) {
      setSelectedLeads(new Set());
    } else {
      setSelectedLeads(new Set(unassignedLeads.map(l => l.id)));
    }
  };

  const handleAssign = () => {
    if (!selectedEmployee) return alert('Please select an employee');
    if (selectedLeads.size === 0) return alert('Please select leads to assign');

    dispatch({
      type: 'ASSIGN_LEADS',
      payload: {
        leadIds: Array.from(selectedLeads),
        employeeId: selectedEmployee
      }
    });
    setSelectedLeads(new Set());
    alert('Leads assigned successfully!');
  };

  const handleDelete = () => {
    if (selectedLeads.size === 0) return alert('Select leads to delete');
    if (window.confirm(`Are you sure you want to delete ${selectedLeads.size} leads?`)) {
      dispatch({
        type: 'DELETE_LEADS',
        payload: Array.from(selectedLeads)
      });
      setSelectedLeads(new Set());
    }
  };

  return (
    <Layout>
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Data Distribution</h1>
          <p className="text-gray-500">Assign incoming leads to your sales team.</p>
        </div>
        <div className="flex gap-4 bg-white p-4 rounded-xl shadow-sm border border-gray-100">
          <select 
            className="px-4 py-2 border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500"
            value={selectedEmployee}
            onChange={(e) => setSelectedEmployee(e.target.value)}
          >
            <option value="">Select Employee</option>
            {employees.map(emp => (
              <option key={emp.id} value={emp.id}>{emp.name} ({emp.id})</option>
            ))}
          </select>
          <button 
            onClick={handleAssign}
            className="bg-indigo-600 text-white px-6 py-2 rounded-lg hover:bg-indigo-700 font-medium disabled:opacity-50 disabled:cursor-not-allowed"
            disabled={!selectedEmployee || selectedLeads.size === 0}
          >
            Assign Selected
          </button>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="p-4 border-b border-gray-100 flex justify-between items-center bg-gray-50">
          <div className="flex items-center gap-3">
             <input 
              type="checkbox" 
              checked={unassignedLeads.length > 0 && selectedLeads.size === unassignedLeads.length}
              onChange={handleSelectAll}
              className="w-5 h-5 text-indigo-600 rounded focus:ring-indigo-500 border-gray-300"
            />
            <span className="font-medium text-gray-700">{unassignedLeads.length} Unassigned Leads</span>
          </div>
          <button 
            onClick={handleDelete}
            className="text-red-600 hover:bg-red-50 px-3 py-1 rounded text-sm font-medium disabled:opacity-50"
            disabled={selectedLeads.size === 0}
          >
            Delete Selected
          </button>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="text-gray-500 bg-gray-50 border-b border-gray-100">
              <tr>
                <th className="w-12 px-6 py-3"></th>
                <th className="px-6 py-3">Name</th>
                <th className="px-6 py-3">Phone</th>
                <th className="px-6 py-3">Location</th>
                <th className="px-6 py-3">Created</th>
              </tr>
            </thead>
            <tbody>
              {unassignedLeads.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-6 py-8 text-center text-gray-500">
                    No unassigned leads available.
                  </td>
                </tr>
              ) : (
                unassignedLeads.map(lead => (
                  <tr key={lead.id} className={`border-b border-gray-50 hover:bg-indigo-50/30 transition-colors ${selectedLeads.has(lead.id) ? 'bg-indigo-50/50' : ''}`}>
                    <td className="px-6 py-4">
                      <input 
                        type="checkbox" 
                        checked={selectedLeads.has(lead.id)}
                        onChange={() => handleToggleLead(lead.id)}
                        className="w-4 h-4 text-indigo-600 rounded focus:ring-indigo-500 border-gray-300"
                      />
                    </td>
                    <td className="px-6 py-4 font-medium text-gray-900">{lead.name}</td>
                    <td className="px-6 py-4 text-gray-500 font-mono">{lead.phone}</td>
                    <td className="px-6 py-4 text-gray-500">{lead.location}</td>
                    <td className="px-6 py-4 text-gray-400 text-xs">
                      {new Date(lead.createdAt).toLocaleDateString()}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </Layout>
  );
};
