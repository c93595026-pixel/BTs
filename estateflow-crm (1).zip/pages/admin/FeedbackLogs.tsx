import React, { useState } from 'react';
import { Layout } from '../../components/Layout';
import { useApp } from '../../contexts/AppContext';
import { Icons } from '../../components/Icons';
import { LeadStatus, UserRole } from '../../types';

export const FeedbackLogs: React.FC = () => {
  const { state } = useApp();
  const [filterEmployee, setFilterEmployee] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  const employees = state.users.filter(u => u.role === UserRole.EMPLOYEE);

  // Filter leads that have actual feedback content
  const feedbackLeads = state.leads
    .filter(l => 
        l.feedback && 
        l.feedback.trim().length > 0 &&
        (filterEmployee ? l.assignedToId === filterEmployee : true) &&
        (searchTerm ? l.name.toLowerCase().includes(searchTerm.toLowerCase()) || l.phone.includes(searchTerm) : true)
    )
    // Sort by latest update (assuming lastUpdated is when feedback was given)
    .sort((a, b) => new Date(b.lastUpdated).getTime() - new Date(a.lastUpdated).getTime());

  const getEmployeeName = (id: string | null | undefined) => {
    if (!id) return 'Unassigned';
    const user = state.users.find(u => u.id === id);
    return user ? user.name : 'Unknown';
  };

  const handleExportCSV = () => {
    if (feedbackLeads.length === 0) {
      alert('No data to export.');
      return;
    }

    // CSV Header
    const headers = ['Entry Time', 'Employee', 'Customer Name', 'Customer Phone', 'Status', 'Feedback', 'Next Follow-up'];
    
    // CSV Rows
    const rows = feedbackLeads.map(lead => {
      const entryTime = new Date(lead.lastUpdated).toLocaleString().replace(/,/g, ''); // Remove commas for CSV safety if simple join
      const employee = getEmployeeName(lead.assignedToId);
      const feedback = lead.feedback ? `"${lead.feedback.replace(/"/g, '""')}"` : ''; // Escape quotes and wrap in quotes
      const followUp = lead.followUpDate ? new Date(lead.followUpDate).toLocaleString().replace(/,/g, '') : '';

      return [
        entryTime,
        employee,
        lead.name,
        lead.phone,
        lead.status,
        feedback,
        followUp
      ].join(',');
    });

    const csvContent = [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `feedback_logs_${new Date().toISOString().slice(0, 10)}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <Layout>
      <div className="mb-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Feedback Logs</h1>
          <p className="text-gray-500">Monitor employee feedback and daily activities across all leads.</p>
        </div>
        <button 
          onClick={handleExportCSV}
          className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-200 text-gray-700 rounded-lg hover:bg-gray-50 text-sm font-medium shadow-sm"
        >
          <Icons.Download className="w-4 h-4" />
          Export CSV
        </button>
      </div>

      <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 mb-6 flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="relative w-full md:w-96">
           <input 
             type="text"
             placeholder="Search customer name or phone..."
             className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
             value={searchTerm}
             onChange={(e) => setSearchTerm(e.target.value)}
           />
           <Icons.Search className="w-5 h-5 absolute left-3 top-2.5 text-gray-400" />
        </div>
        
        <div className="w-full md:w-64">
            <select 
                className="w-full px-4 py-2 border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-indigo-500"
                value={filterEmployee}
                onChange={(e) => setFilterEmployee(e.target.value)}
            >
                <option value="">All Employees</option>
                {employees.map(emp => (
                    <option key={emp.id} value={emp.id}>{emp.name}</option>
                ))}
            </select>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
                <thead className="text-gray-500 bg-gray-50 border-b border-gray-100">
                    <tr>
                        <th className="px-6 py-3">Entry Time</th>
                        <th className="px-6 py-3">Employee</th>
                        <th className="px-6 py-3">Customer</th>
                        <th className="px-6 py-3">Status</th>
                        <th className="px-6 py-3 w-1/3">Feedback</th>
                        <th className="px-6 py-3">Next Follow-up</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                    {feedbackLeads.length === 0 ? (
                        <tr>
                            <td colSpan={6} className="px-6 py-12 text-center text-gray-400">
                                <div className="flex flex-col items-center justify-center gap-2">
                                    <Icons.ClipboardList className="w-8 h-8 text-gray-300" />
                                    <p>No feedback records found.</p>
                                </div>
                            </td>
                        </tr>
                    ) : (
                        feedbackLeads.map(lead => (
                            <tr key={lead.id} className="hover:bg-gray-50 transition-colors">
                                <td className="px-6 py-4 whitespace-nowrap">
                                    <div className="font-medium text-gray-900">{new Date(lead.lastUpdated).toLocaleDateString()}</div>
                                    <div className="text-xs text-gray-500">{new Date(lead.lastUpdated).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit'})}</div>
                                </td>
                                <td className="px-6 py-4 font-medium text-indigo-600">
                                    {getEmployeeName(lead.assignedToId)}
                                </td>
                                <td className="px-6 py-4">
                                    <div className="font-medium text-gray-900">{lead.name}</div>
                                    <div className="text-xs text-gray-500 font-mono">{lead.phone}</div>
                                </td>
                                <td className="px-6 py-4">
                                     <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                                        lead.status === LeadStatus.INTERESTED ? 'bg-green-100 text-green-700' :
                                        lead.status === LeadStatus.CLOSED ? 'bg-emerald-100 text-emerald-700' :
                                        lead.status === LeadStatus.CALLBACK ? 'bg-yellow-100 text-yellow-700' :
                                        lead.status === LeadStatus.NOT_INTERESTED ? 'bg-red-100 text-red-700' :
                                        'bg-gray-100 text-gray-600'
                                      }`}>
                                        {lead.status}
                                      </span>
                                </td>
                                <td className="px-6 py-4 text-gray-600 italic">
                                    "{lead.feedback}"
                                </td>
                                <td className="px-6 py-4">
                                    {lead.followUpDate ? (
                                        <div className="flex items-center gap-1 text-orange-600 bg-orange-50 px-2 py-1 rounded w-fit">
                                            <Icons.Clock className="w-3 h-3" />
                                            <span className="text-xs font-medium">
                                                {new Date(lead.followUpDate).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute:'2-digit'})}
                                            </span>
                                        </div>
                                    ) : (
                                        <span className="text-gray-300 text-xs">-</span>
                                    )}
                                </td>
                            </tr>
                        ))
                    )}
                </tbody>
            </table>
        </div>
      </div>
    </Layout>
  );
};