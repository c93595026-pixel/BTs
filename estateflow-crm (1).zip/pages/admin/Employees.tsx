import React, { useState } from 'react';
import { Layout } from '../../components/Layout';
import { useApp } from '../../contexts/AppContext';
import { UserRole } from '../../types';
import { Icons } from '../../components/Icons';

export const Employees: React.FC = () => {
  const { state, dispatch } = useApp();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false);
  const [selectedEmployeeForPassword, setSelectedEmployeeForPassword] = useState<string | null>(null);
  const [newEmployeePassword, setNewEmployeePassword] = useState('');
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    address: '',
    experience: '',
    designation: '',
  });

  const generateId = () => {
    const count = state.users.filter(u => u.role === UserRole.EMPLOYEE).length;
    return `EMP${String(count + 1).padStart(3, '0')}`;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newEmp = {
      id: generateId(),
      role: UserRole.EMPLOYEE,
      password: 'password', // Default password
      joiningDate: new Date().toISOString(),
      availabilityStatus: 'WORKING' as const, // Default to working
      ...formData
    };
    dispatch({ type: 'ADD_USER', payload: newEmp });
    setIsModalOpen(false);
    setFormData({ name: '', phone: '', address: '', experience: '', designation: '' });
  };

  const handlePasswordUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedEmployeeForPassword && newEmployeePassword) {
        dispatch({
            type: 'UPDATE_USER_PASSWORD',
            payload: { userId: selectedEmployeeForPassword, newPass: newEmployeePassword }
        });
        alert('Employee password updated successfully');
        setIsPasswordModalOpen(false);
        setNewEmployeePassword('');
        setSelectedEmployeeForPassword(null);
    }
  };

  const handleResetPassword = (e: React.MouseEvent, userId: string) => {
    e.stopPropagation();
    if (window.confirm('Are you sure you want to reset this employee\'s password to the default "password"?')) {
      dispatch({
        type: 'UPDATE_USER_PASSWORD',
        payload: { userId: userId, newPass: 'password' }
      });
      alert('Password reset to "password" successfully.');
    }
  };

  const openPasswordModal = (e: React.MouseEvent, userId: string) => {
      e.stopPropagation();
      setSelectedEmployeeForPassword(userId);
      setIsPasswordModalOpen(true);
  };

  const toggleSelection = (id: string) => {
    const newSet = new Set(selectedIds);
    if (newSet.has(id)) newSet.delete(id);
    else newSet.add(id);
    setSelectedIds(newSet);
  };

  const handleDelete = () => {
    if (selectedIds.size === 0) return;
    if (window.confirm(`Are you sure you want to delete ${selectedIds.size} employees? Leads assigned to them will become unassigned.`)) {
      dispatch({ type: 'DELETE_USERS', payload: Array.from(selectedIds) });
      setSelectedIds(new Set());
    }
  };

  const employees = state.users.filter(u => u.role === UserRole.EMPLOYEE);

  return (
    <Layout>
       <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Employee Management</h1>
          <p className="text-gray-500">Create and manage your team credentials.</p>
        </div>
        <div className="flex gap-3 w-full md:w-auto">
          {selectedIds.size > 0 && (
            <button
              onClick={handleDelete}
              className="bg-red-600 text-white px-6 py-2.5 rounded-lg hover:bg-red-700 font-medium flex items-center gap-2 shadow-sm shadow-red-200 animate-in fade-in slide-in-from-bottom-1 duration-200 flex-1 md:flex-none justify-center"
            >
              <Icons.Trash className="w-5 h-5" />
              Delete ({selectedIds.size})
            </button>
          )}
          <button 
            onClick={() => setIsModalOpen(true)}
            className="bg-indigo-600 text-white px-6 py-2.5 rounded-lg hover:bg-indigo-700 font-medium flex items-center gap-2 shadow-sm shadow-indigo-200 flex-1 md:flex-none justify-center"
          >
            <Icons.Users className="w-5 h-5" />
            Add New
          </button>
        </div>
      </div>

      {employees.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-xl border border-gray-100">
          <div className="bg-indigo-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
            <Icons.Users className="w-8 h-8 text-indigo-400" />
          </div>
          <h3 className="text-lg font-medium text-gray-900">No Employees Yet</h3>
          <p className="text-gray-500 mt-1">Get started by adding your first team member.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {employees.map(emp => (
            <div 
              key={emp.id} 
              onClick={() => toggleSelection(emp.id)}
              className={`group relative bg-white p-6 rounded-xl shadow-sm border transition-all cursor-pointer ${
                selectedIds.has(emp.id) 
                  ? 'border-indigo-500 ring-1 ring-indigo-500 bg-indigo-50/10' 
                  : 'border-gray-100 hover:shadow-md hover:border-indigo-200'
              }`}
            >
              <div className="absolute top-4 right-4 z-10">
                <input 
                  type="checkbox" 
                  checked={selectedIds.has(emp.id)} 
                  onChange={() => toggleSelection(emp.id)}
                  className="w-5 h-5 text-indigo-600 rounded border-gray-300 focus:ring-indigo-500 cursor-pointer"
                />
              </div>
              
              <div className="flex justify-between items-start mb-4">
                <div className="w-12 h-12 bg-indigo-50 rounded-full flex items-center justify-center text-indigo-600 font-bold text-xl">
                  {emp.name.charAt(0)}
                </div>
                {emp.availabilityStatus === 'ON_LEAVE' ? (
                    <span className="bg-orange-100 text-orange-700 px-2 py-1 rounded text-xs font-semibold mr-8 flex items-center gap-1">
                        <span className="w-2 h-2 bg-orange-500 rounded-full"></span>
                        On Leave
                    </span>
                ) : (
                    <span className="bg-green-100 text-green-700 px-2 py-1 rounded text-xs font-semibold mr-8 flex items-center gap-1">
                        <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                        Working
                    </span>
                )}
              </div>
              
              <h3 className="font-bold text-lg text-gray-900">{emp.name}</h3>
              <p className="text-sm text-gray-500 mb-4">{emp.designation || 'Sales Agent'}</p>
              
              <div className="space-y-2 text-sm text-gray-600 border-t border-gray-50 pt-4">
                <div className="flex justify-between">
                  <span>ID:</span>
                  <span className="font-mono font-semibold">{emp.id}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Password:</span>
                  <div className="flex items-center gap-2">
                    <span className="font-mono bg-gray-100 px-2 py-0.5 rounded text-xs">{emp.password}</span>
                    <button 
                        onClick={(e) => openPasswordModal(e, emp.id)}
                        className="text-xs text-indigo-600 hover:text-indigo-800 hover:underline font-medium"
                    >
                        Change
                    </button>
                    <span className="text-gray-300">|</span>
                    <button 
                        onClick={(e) => handleResetPassword(e, emp.id)}
                        className="text-xs text-red-500 hover:text-red-700 hover:underline font-medium"
                    >
                        Reset
                    </button>
                  </div>
                </div>
                 <div className="flex justify-between">
                  <span>Experience:</span>
                  <span>{emp.experience || 'N/A'}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* New Employee Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg p-8 shadow-2xl">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Register New Employee</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                <input required className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-indigo-500 outline-none" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                  <input required className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-indigo-500 outline-none" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Designation</label>
                  <input className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-indigo-500 outline-none" value={formData.designation} onChange={e => setFormData({...formData, designation: e.target.value})} />
                </div>
              </div>
               <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Address</label>
                <input className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-indigo-500 outline-none" value={formData.address} onChange={e => setFormData({...formData, address: e.target.value})} />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Experience</label>
                <input className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-indigo-500 outline-none" value={formData.experience} onChange={e => setFormData({...formData, experience: e.target.value})} placeholder="e.g. 2 Years" />
              </div>
              
              <div className="flex gap-3 mt-8 pt-4 border-t border-gray-100">
                <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 py-2.5 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">Cancel</button>
                <button type="submit" className="flex-1 py-2.5 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">Create Account</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Update Password Modal */}
      {isPasswordModalOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl w-full max-w-sm p-6 shadow-2xl">
            <h3 className="text-lg font-bold text-gray-900 mb-4">Update Employee Password</h3>
            <form onSubmit={handlePasswordUpdate} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">New Password</label>
                <input 
                  type="text" 
                  required 
                  value={newEmployeePassword} 
                  onChange={(e) => setNewEmployeePassword(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-indigo-500 outline-none"
                  placeholder="Enter new password"
                />
              </div>
              <div className="flex gap-3 pt-2">
                <button 
                  type="button" 
                  onClick={() => setIsPasswordModalOpen(false)} 
                  className="flex-1 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="flex-1 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
                >
                  Update
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </Layout>
  );
};
